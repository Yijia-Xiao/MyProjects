#include "prob.h"
#include "ui_prob.h"

ProB::ProB(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProB)
{
    ui->setupUi(this);
    GB = new QButtonGroup(this);
    GB->addButton(ui->radioButton, 1);
    GB->addButton(ui->radioButton_2, 2);
    GB->addButton(ui->radioButton_3, 3);
    GB->addButton(ui->radioButton_4, 4);
}

ProB::~ProB()
{
    delete ui;
}
