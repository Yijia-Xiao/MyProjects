#include "connecting.h"
#include "ui_connecting.h"
#include "mainwindow.h"

connecting::connecting(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::connecting)
{
    ui->setupUi(this);
}

connecting::~connecting()
{
    delete ui;
}

void connecting::on_pushOK_clicked()
{
    this->close();
}

void connecting::on_pushCancel_clicked()
{

}
