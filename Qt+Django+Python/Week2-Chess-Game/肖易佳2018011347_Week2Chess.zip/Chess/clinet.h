#ifndef CLINET_H
#define CLINET_H

#include <QDialog>

namespace Ui {
class Clinet;
}

class Clinet : public QDialog
{
    Q_OBJECT

public:
    explicit Clinet(QWidget *parent = nullptr);
    ~Clinet();
    QString getAdr();

private:
    Ui::Clinet *ui;
};

#endif // CLINET_H
