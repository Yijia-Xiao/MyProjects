#include "savelog.h"
#include "ui_savelog.h"

SaveLog::SaveLog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SaveLog)
{
    ui->setupUi(this);
}

SaveLog::~SaveLog()
{
    delete ui;
}
QString SaveLog::savePath()
{
    return this->ui->lineEdit->text();
}
