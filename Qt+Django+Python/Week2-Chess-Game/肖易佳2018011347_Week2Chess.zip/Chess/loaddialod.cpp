#include "loaddialod.h"
#include "ui_loaddialod.h"

LoadDialod::LoadDialod(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoadDialod)
{
    ui->setupUi(this);
}

LoadDialod::~LoadDialod()
{
    delete ui;
}
