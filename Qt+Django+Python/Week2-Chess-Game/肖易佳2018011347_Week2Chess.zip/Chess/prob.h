#ifndef PROB_H
#define PROB_H

#include <QDialog>
#include <QButtonGroup>

namespace Ui {
class ProB;
}

class ProB : public QDialog
{
    Q_OBJECT

public:
    explicit ProB(QWidget *parent = nullptr);
    ~ProB();
    QButtonGroup *GB;
private:
    Ui::ProB *ui;
};

#endif // PROB_H
