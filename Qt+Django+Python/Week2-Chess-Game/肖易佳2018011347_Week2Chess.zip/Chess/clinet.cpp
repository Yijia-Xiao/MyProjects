#include "clinet.h"
#include "ui_clinet.h"

Clinet::Clinet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Clinet)
{
    ui->setupUi(this);
}

Clinet::~Clinet()
{
    delete ui;
}

QString Clinet::getAdr()
{
    return ui->lineEnterAddr->text();
}
