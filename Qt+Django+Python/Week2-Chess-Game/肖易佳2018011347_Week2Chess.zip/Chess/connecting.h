#ifndef CONNECTING_H
#define CONNECTING_H

#include <QDialog>

namespace Ui {
class connecting;
}

class connecting : public QDialog
{
    Q_OBJECT

public:
    explicit connecting(QWidget *parent = nullptr);
    ~connecting();

private slots:
//    void on_buttonBox_accepted();

//    void on_buttonBox_accepted();

    void on_pushOK_clicked();

    void on_pushCancel_clicked();

private:
    Ui::connecting *ui;
};

#endif // CONNECTING_H
