#ifndef LOADDIALOD_H
#define LOADDIALOD_H

#include <QDialog>

namespace Ui {
class LoadDialod;
}

class LoadDialod : public QDialog
{
    Q_OBJECT

public:
    explicit LoadDialod(QWidget *parent = nullptr);
    ~LoadDialod();

private:
    Ui::LoadDialod *ui;
};

#endif // LOADDIALOD_H
