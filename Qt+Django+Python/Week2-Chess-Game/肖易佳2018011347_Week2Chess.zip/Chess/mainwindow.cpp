#include "mainwindow.h"
#include "ui_mainwindow.h"

const int TIME_LIMIT = 60;
using namespace std;
static Grid a[9][9];
static Point src;
static Point dst;
static int ctr = 0;
static bool bFirst[9][9];
static bool whiteSide = true;
static bool myTurn = true;
static char mySide = 'b';
static int timeLeft = TIME_LIMIT;
//static Point curp;
//void init();
//void load();
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    init();
    this->repaint();
    timer = new QTimer;
    connect(timer, SIGNAL(timeout()), this, SLOT(updateTime())); // SLOT填入一个槽函数
//    timer->start(1000);


//    timer->start(1000); // 1000毫秒, 等于 1 秒
//    bb.load("./images/bb.png");
}
bool checkDanger(char);
static bool valid[9] = {true};
int sCheck();
static int Tempb = 4;
static int tx = (8 + 1) / 3;
static int ty = 6;
MainWindow::~MainWindow()
{
    delete ui;
}
static Point spePos(8, 4);
void MainWindow::paintEvent(QPaintEvent *event)
{
    QPixmap bb,bw,cb,cw,hb,hw,mb,mw,wb,ww,xb,xw;
    bb.load("E:\\Chess\\images\\bb.png");
    bw.load("E:\\Chess\\images\\bw.png");
    cb.load("E:\\Chess\\images\\cb.png");
    cw.load("E:\\Chess\\images\\cw.png");
    hb.load("E:\\Chess\\images\\hb.png");
    hw.load("E:\\Chess\\images\\hw.png");
    mb.load("E:\\Chess\\images\\mb.png");
    mw.load("E:\\Chess\\images\\mw.png");
    wb.load("E:\\Chess\\images\\wb.png");
    ww.load("E:\\Chess\\images\\ww.png");
    xb.load("E:\\Chess\\images\\xb.png");
    xw.load("E:\\Chess\\images\\xw.png");
    QPainter p(this);
    p.translate(40, 40);
//    p.rotate(-90);
//    p.setWindow(-160,160,160,-160);
    for (int i = 1; i < 9; ++i) {
        int ctr = (i % 2 == 0? 0 : 1);
        for (int j = 1; j < 9; j++) {
            ctr++;
            if(ctr % 2){
                p.setBrush(Qt::white);
            }
            else {
                p.setBrush(QColor(180, 180, 180));
            }
            p.drawRect((i - 1) * 40, (j - 1) * 40, 40, 40);
            QString temp = "k0";
            temp[0] = a[i][j].type;
            temp[1] = (a[i][j].isWhite ? 'w':'b');
            p.drawText((i - 1) * 40, (j - 1) * 40 + 10, temp);
        }
    }
//    p.drawPixmap(0, 0, 40, 40, bb);
    for(int i = 1; i < 9; i ++){
        for (int j = 1; j < 9; j ++) {
            if(a[i][j].type == 'k')
                continue;
            else{
                switch (a[i][j].type) {
                case 'b':
                    if(a[i][j].isWhite){
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, bw);
                        break;
                    }
                    else {
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, bb);
                        break;
                    }
                case 'c':
                    if(a[i][j].isWhite){
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, cw);
                        break;
                    }
                    else {
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, cb);
                        break;
                    }
                case 'h':
                    if(a[i][j].isWhite){
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, hw);
                        break;
                    }
                    else {
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, hb);
                        break;
                    }
                case 'm':
                    if(a[i][j].isWhite){
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, mw);
                        break;
                    }
                    else {
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, mb);
                        break;
                    }
                case 'w':
                    if(a[i][j].isWhite){
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, ww);
                        break;
                    }
                    else {
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, wb);
                        break;
                    }
                case 'x':
                    if(a[i][j].isWhite){
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, xw);
                        break;
                    }
                    else {
                        p.drawPixmap((i-1)*40, (j-1)*40, 40, 40, xb);
                        break;
                    }
                }
            }
        }
    }
}


void MainWindow::mousePressEvent(QMouseEvent *mevent)
{
    // 检查是否轮到自己++++++++++++++++++++++++++++++++++++
    if(!myTurn){
        QMessageBox::information(this, "NOT YOUR TURN", "Please wait for the other player");
        return;
    }
    int x = (mevent->x() - 40) / 40 + 1;
    int y = (mevent->y() - 40) / 40 + 1;
    if(mevent->button() == Qt::LeftButton){
        src.x = x;
        src.y = y;
        ctr++;
    }
    else if(mevent->button() == Qt::RightButton){
        dst.x = x;
        dst.y = y;
        ctr++;
    }
    // 检查是否操作自己的棋子++++++++++++++++++++++++++++++++++++
    if(! ((a[src.x][src.y].isWhite && mySide == 'w') || (!a[src.x][src.y].isWhite && mySide == 'b')) ){
        QMessageBox::information(this, "Not Yours", "Please Re-Select");
        return;
    }

    if(ctr % 2 == 0){
        bool isValid = true;
        //注意不可以重合

        //b 兵的部分

        if(a[src.x][src.y].isWhite == a[dst.x][dst.y].isWhite && a[dst.x][dst.y].type != 'k'){
            isValid = false;
//            QMessageBox::information(this, "Itself", "You cannot eat yourself!");
        }

        //Eat the other side
        else {
            if(a[src.x][src.y].type == 'b'){
//                highLight(src.x, src.y);
                if(a[src.x][src.y].isWhite){
                    //WHITE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    if(src.x == 2){
                        if(dst.x == src.x +1){
                            if( abs(dst.y - src.y) == 1 ){
//                                if( (a[src.x + 1][src.y - 1].type !='k' && !a[src.x + 1][src.y - 1].isWhite) || (a[src.x + 1][src.y + 1].type !='k' && !a[src.x + 1][src.y + 1].isWhite) );
                                if( (a[dst.x][src.y - 1].type !='k' && !a[dst.x][src.y - 1].isWhite) || (a[dst.x][src.y + 1].type !='k' && !a[dst.x][src.y + 1].isWhite) )
                                    isValid = true;
                                else
                                    isValid = false;
                            }
                            //后改的！！
                            else if(dst.y == src.y && a[dst.x][dst.y].type == 'k')
                                isValid = true;
                            else {
                                isValid = false;
                            }
                        }
                        else if(dst.x == src.x + 2){
//                            if(a[src.x + 2] [dst.y].type == 'k');
                            if(a[dst.x] [dst.y].type == 'k' && dst.y == src.y)
                                isValid = true;
                            else {
                                isValid = false;
                            }
                        }
                        //x 方向移动>=3
                        else {
                            isValid = false;
                        }

                    }
                    else if(src.x == 7){
                        if(dst.x != src.x + 1)
                            isValid = false;
                        else if( (dst.y == src.y && a[dst.x][dst.y].type == 'k') || (dst.y == src.y+1 && a[dst.x][dst.y].type != 'k') || (dst.y == src.y-1 && a[dst.x][dst.y].type != 'k') ){
                            ProB * selectB = new ProB(this);
                            selectB->show();
                            char proed = '\0';
                            if(selectB->exec()){
                                if(selectB->GB->checkedId() == 1)
                                    proed = 'h';
                                if(selectB->GB->checkedId() == 2)
                                    proed = 'c';
                                if(selectB->GB->checkedId() == 3)
                                    proed = 'x';
                                if(selectB->GB->checkedId() == 4)
                                    proed = 'm';
                            }
                            isValid = true;
                            QMessageBox::information(this, "Promoted!", "Your Pawn Has Been Promoted!");
                            if(isValid){
//                                (proed == 'c' || proed == 'h')
                                if(sCheck()){
                                    QMessageBox::information(this, "Tie", "逼和!\n The game is over!");
//                                    exit(0);
                                }
                                a[dst.x][dst.y].type = a[src.x][src.y].type;
                                a[src.x][src.y].type = 'k';
                                a[dst.x][dst.y].isWhite = a[src.x][src.y].isWhite;
                                myTurn = false;
                                timer->stop();
                                ui->lcdNumber->display(TIME_LIMIT);
                                checkMyKing();

                            }
//                            sendData();
                            a[dst.x][dst.y].type = proed;
                            sendData();
                            this->repaint();
                            if(proed == '\0')
                                cout << "WRONG IN proed == '\0'" << endl;
                            return;
                        }
                        else {
                            isValid = false;
                        }
                    }
                    else if(src.x > 2 && src.x < 7){

                        if(dst.x != src.x + 1){
                            isValid = false;
                        }

                        else {
                            if(dst.y == src.y){
                                if(a[dst.x][dst.y].type == 'k')
                                    isValid = true;
                                else
                                    isValid = false;
                            }
                            else if(abs(dst.y - src.y) == 1){
                                if(a[dst.x][dst.y].type != 'k'){
                                    isValid = true;
                                }
                                else{
                                    isValid = false;
                                    cout << "XIE ZHE CHI 1 PROBLEM" << endl;
                                }
                            }
                            else {
                                cout << "WRONG IN WHITE LINE 3 to 6" << endl;
                            }
                        }
                    }
                    else{
                        cout << "SOMETHING WRONG IN PAWN... WHITE PART" << endl;
                    }
                }


                //BLACK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                else {
                    if(src.x == 7){
                        if(dst.x == src.x -1){
                            if( abs(dst.y - src.y) == 1 ){
                                if( (a[dst.x][src.y - 1].type !='k' && a[dst.x][src.y - 1].isWhite) || (a[dst.x][src.y + 1].type !='k' && a[dst.x][src.y + 1].isWhite) )
//                                    if( (a[src.x - 1][src.y - 1].type !='k' && !a[src.x - 1][src.y - 1].isWhite) || (a[src.x - 1][src.y + 1].type !='k' && !a[src.x - 1][src.y + 1].isWhite) )
                                    isValid = true;
                                else
                                    isValid = false;
                            }
                            else if(dst.y == src.y)
                                isValid = true;
                            else {
                                isValid = false;
                            }
                        }
                        else if(dst.x == src.x - 2){
                            if(a[dst.x] [dst.y].type == 'k' && dst.y == src.y)
                                isValid = true;
                            else {
                                isValid = false;
                            }
                        }
                        //x 方向移动>=3
                        else {
                            isValid = false;
                        }

                    }
                    else if(src.x == 2){
                        if(dst.x != src.x - 1)
                            isValid = false;
                        else if( (dst.y == src.y && a[dst.x][dst.y].type == 'k') || (dst.y == src.y+1 && a[dst.x][dst.y].type != 'k') || (dst.y == src.y-1 && a[dst.x][dst.y].type != 'k') ){
                            ProB * selectB = new ProB(this);
                            selectB->show();
                            char proed = '\0';
                            if(selectB->exec()){
                                if(selectB->GB->checkedId() == 1)
                                    proed = 'h';
                                if(selectB->GB->checkedId() == 2)
                                    proed = 'c';
                                if(selectB->GB->checkedId() == 3)
                                    proed = 'x';
                                if(selectB->GB->checkedId() == 4)
                                    proed = 'm';
                            }
                            isValid = true;
                            QMessageBox::information(this, "Promoted!", "Your Pawn Has Been Promoted!");
                            if(isValid){
//                                (proed == 'c' || proed == 'h')
                                if(sCheck()){
                                    QMessageBox::information(this, "Tie", "逼和!\n The game is over!");
//                                    exit(0);
                                }
                                a[dst.x][dst.y].type = a[src.x][src.y].type;
                                a[src.x][src.y].type = 'k';
                                a[dst.x][dst.y].isWhite = a[src.x][src.y].isWhite;
                                myTurn = false;
                                timer->stop();
                                ui->lcdNumber->display(TIME_LIMIT);
                                checkMyKing();
//                                this->repaint();
//                                sendData();

                            }
//                            sendData();
                            a[dst.x][dst.y].type = proed;
                            sendData();
                            this->repaint();
                            if(proed == '\0')
                                cout << "WRONG IN proed == '\0'" << endl;
                            //TCP
                            return;
                        }
                        else {
                            isValid = false;
                        }
                    }
                    else if(src.x > 2 && src.x < 7){

                        if(dst.x != src.x - 1){
                            isValid = false;
                        }

                        else {
                            if(dst.y == src.y){
                                if(a[dst.x][dst.y].type == 'k')
                                    isValid = true;
                                else
                                    isValid = false;
                            }
                            else if(abs(dst.y - src.y) == 1){
                                if(a[dst.x][dst.y].type != 'k'){
                                    isValid = true;
                                }
                                else{
                                    isValid = false;
                                    qDebug() << tr("XIE ZHE CHI 2 PROBLEM") << endl;
                                }
                            }
                            else {
                                cout << "WRONG IN WHITE LINE 3 to 6" << endl;
                            }
                        }
                    }
                    else{
                        cout << "SOMETHING WRONG IN PAWN... WHITE PART" << endl;
                    }

                }
            }
            if(a[src.x][src.y].type == 'c'){
                if(src.x!=dst.x && src.y!=dst.y)
                    isValid = false;
                else {
                    if(src.x==dst.x){
                        for(int i = min(src.y, dst.y)+1; i < max(src.y, dst.y); i++)
                            if(a[x][i].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }
                    else if(src.y==dst.y){
                        for(int i = min(src.x, dst.x)+1; i < max(src.x, dst.x); i++)
                            if(a[i][y].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }
                }
            }

            if(a[src.x][src.y].type == 'm'){
                if( (abs(dst.x - src.x)==1 && abs(dst.y - src.y)==2) || (abs(dst.x - src.x)==2 && abs(dst.y - src.y)==1) )
                    isValid = true;
                else
                    isValid = false;
            }

            if(a[src.x][src.y].type == 'x'){

                if( abs(src.x - dst.x) != abs(src.y - dst.y) )
                    isValid = false;

                else {
//                    cout << "XXX" << endl;
                    if(src.x < dst.x && src.y < dst.y){
                        for(int i = 1; i < abs(dst.x - src.x); i++)
                            if(a[src.x + i][src.y + i].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }

                    else if(src.x < dst.x && src.y > dst.y){
                        for(int i = 1; i < abs(dst.x - src.x); i++)
                            if(a[src.x + i][src.y - i].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }

                    else if(src.x > dst.x && src.y < dst.y){
                        for(int i = 1; i < abs(dst.x - src.x); i++)
                            if(a[src.x - i][src.y + i].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }

                    else if(src.x > dst.x && src.y > dst.y){
                        for(int i = 1; i < abs(dst.x - src.x); i++)
                            if(a[src.x - i][src.y - i].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }

                }

            }

            if(a[src.x][src.y].type == 'h'){
                if( !( src.x == dst.x || src.y == dst.y || abs(src.x - dst.x) == abs(src.y - dst.y) ) )
                    isValid = false;
                else{
                    if(src.x==dst.x){
                        for(int i = min(src.y, dst.y)+1; i < max(src.y, dst.y); i++)
                            if(a[x][i].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }
                    else if(src.y==dst.y){
                        for(int i = min(src.x, dst.x)+1; i < max(src.x, dst.x); i++)
                            if(a[i][y].type != 'k'){
                                isValid = false;
                                break;
                            }
                    }
                    else{
                        if(src.x < dst.x && src.y < dst.y){
                            for(int i = 1; i < abs(dst.x - src.x); i++)
                                if(a[src.x + i][src.y + i].type != 'k'){
                                    isValid = false;
                                    break;
                                }
                        }

                        else if(src.x < dst.x && src.y > dst.y){
                            for(int i = 1; i < abs(dst.x - src.x); i++)
                                if(a[src.x + i][src.y - i].type != 'k'){
                                    isValid = false;
                                    break;
                                }
                        }

                        else if(src.x > dst.x && src.y < dst.y){
                            for(int i = 1; i < abs(dst.x - src.x); i++)
                                if(a[src.x - i][src.y + i].type != 'k'){
                                    isValid = false;
                                    break;
                                }
                        }

                        else if(src.x > dst.x && src.y > dst.y){
                            for(int i = 1; i < abs(dst.x - src.x); i++)
                                if(a[src.x - i][src.y - i].type != 'k'){
                                    isValid = false;
                                    break;
                                }
                        }
                    }
                }
            }


            if(a[src.x][src.y].type == 'w'){
                if( abs(dst.x-src.x) <=1 && abs(dst.y-src.y) <=1 )
                    isValid = true;
                else {
                    isValid = false;
                }
            }

        }

//        if(a[src.x][src.y].type == 'k'){
//            ctr--;
//            QMessageBox::information(this, "Not valid", "The GRID is not valid");
//        }


        if(isValid){
//            myTurn = false;
            if(sCheck()){
                QMessageBox::information(this, "Tie", "逼和!\n The game is over!");
//                exit(0);
            }
            a[dst.x][dst.y].type = a[src.x][src.y].type;
            a[src.x][src.y].type = 'k';
            a[dst.x][dst.y].isWhite = a[src.x][src.y].isWhite;
            qDebug() << "isValid" << endl;
            myTurn = false;
            timer->stop();
            ui->lcdNumber->display(TIME_LIMIT);
            checkMyKing();
//TCP
//            emit this->moved();
            this->repaint();
            sendData();
        }
        else {
            QMessageBox::information(this, "Not valid", "The move is not valid");
        }
    }
}

void MainWindow::init()
{
    for (int i = 0; i < 9; i++) {
        for(int j = 0; j < 9; j++)
            bFirst[i][j] = true;
    }
    a[1][1].type = 'c'; a[1][2].type = 'm'; a[1][3].type = 'x'; a[1][4].type = 'h';
    a[1][5].type = 'w'; a[1][6].type = 'x'; a[1][7].type = 'm'; a[1][8].type = 'c';
    a[8][1].type = 'c'; a[8][2].type = 'm'; a[8][3].type = 'x'; a[8][4].type = 'h';
    a[8][5].type = 'w'; a[8][6].type = 'x'; a[8][7].type = 'm'; a[8][8].type = 'c';
    for(int i = 1; i < 9; i ++){
        a[1][i].isWhite = a[2][i].isWhite = true;
        a[7][i].isWhite = a[8][i].isWhite = false;
        a[2][i].type = a[7][i].type = 'b';
    }
}
void MainWindow::load()
{

    QFileDialog *dialog = new QFileDialog;
    QString path = dialog->getOpenFileName();
    if(path==""){
        return;
    }
    clear();
    ifstream fin(path.toStdString());
    string side, type, posi;
    int number;
    fin >> side;
    map<string, char> sc;
    sc["king"] = 'w'; sc["queen"] = 'h'; sc["knight"] = 'm'; sc["rook"] = 'c'; sc["bishop"] = 'x'; sc["pawn"] = 'b';
    map<char, int> posmap;
    posmap['a'] = 1; posmap['b'] = 2; posmap['c'] = 3; posmap['d'] = 4; posmap['e'] = 5; posmap['f'] = 6; posmap['g'] = 7; posmap['h'] = 8;
    posmap['1'] = 1; posmap['2'] = 2; posmap['3'] = 3; posmap['4'] = 4; posmap['5'] = 5; posmap['6'] = 6; posmap['7'] = 7; posmap['8'] = 8;

    whiteSide = (side == "white");
//white First!!!
    if(whiteSide){
        while(true){
            fin >> type;

            if(type == "black")
                break;

            fin >> number;
            for(int i = 0; i < number; i++){
                fin >> posi;
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].type = sc[type];
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].isWhite = whiteSide;
            }
        }
        while(!fin.eof()){
            fin >> type;
            fin >> number;
            for(int i = 0; i < number; i++){
                fin >> posi;
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].type = sc[type];
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].isWhite = !whiteSide;
            }
        }
    }
    else{
        while(true){
            fin >> type;

            if(type == "white")
                break;

            fin >> number;
            for(int i = 0; i < number; i++){
                fin >> posi;
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].type = sc[type];
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].isWhite = whiteSide;
            }
        }
        while(!fin.eof()){
            fin >> type;
            fin >> number;
            for(int i = 0; i < number; i++){
                fin >> posi;
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].type = sc[type];
                a[ posmap[posi[1]] ] [ posmap[posi[0]] ].isWhite = !whiteSide;
            }
        }
    }

    this->repaint();
}


void MainWindow::clear()
{
    for(int i = 1; i < 9; i++)
        for (int j = 1; j < 9; j++) {
            a[i][j].type = 'k';
            a[i][j].isWhite = true;
        }
}

void MainWindow::on_actionNewGame_triggered()
{
    this->clear();
    this->init();
    sendData();
    this->repaint();
}

void MainWindow::on_actionLoadaGame_triggered()
{
    load();
    sendData();
    this->repaint();
}

void MainWindow::on_actionSaveGame_triggered()
{
    string saveData;
    //w1 h2 x3 m4 c5 b6
    map<char, int> m;
    map<int, string> second;
    m['w'] = 1; m['h'] = 2; m['c'] = 3; m['x'] = 4; m['m'] = 5; m['b'] = 6;
    second[1] = "a";
    second[2] = "b";
    second[3] = "c";
    second[4] = "d";
    second[5] = "e";
    second[6] = "f";
    second[7] = "g";
    second[8] = "h";
    string white = "white\n", black = "black\n";
    vector<string> ww, hw, cw, xw, mw, bw;
    vector<string> wb, hb, cb, xb, mb, bb;

//    int numWhite[7] = {0};
//    int numBlack[7] = {0};
    for(int i = 1; i < 9; i++)
        for(int j = 1; j < 9; j++){
            if(a[i][j].type == 'k')
                continue;
            else {
                if(a[i][j].isWhite){
                    if(a[i][j].type == 'w'){
                        ww.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'h'){
                        hw.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'c'){
                        cw.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'x'){
                        xw.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'm'){
                        mw.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'b'){
                        bw.push_back(second[j]+to_string(i));
                    }
                }
                else {
                    if(a[i][j].type == 'w'){
                        wb.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'h'){
                        hb.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'c'){
                        cb.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'x'){
                        xb.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'm'){
                        mb.push_back(second[j]+to_string(i));
                    }
                    if(a[i][j].type == 'b'){
                        bb.push_back(second[j]+to_string(i));
                    }
                }
            }
        }
    SaveLog *save = new SaveLog(this);
    QString Path;
//    string path;
    if(save->exec())
        Path = save->savePath();

    ofstream fout(Path.toStdString());

    // || (!myTurn && mySide == 'b')
    if((myTurn && mySide == 'w')){

        //WHITEWHITEWHITE!!!!!!!!!!

        fout << "white\n";
        fout << "king " << ww.size() <<" ";
        for(unsigned i = 0; i < ww.size(); i++)
            fout << ww[i] << " ";
        fout << endl;

        fout << "queen " << hw.size() <<" ";
        for(unsigned i = 0; i < hw.size(); i++)
            fout << hw[i] << " ";
        fout << endl;

        fout << "rook " << cw.size() <<" ";
        for(unsigned i = 0; i < cw.size(); i++)
            fout << cw[i] << " ";
        fout << endl;

        fout << "bishop " << xw.size() <<" ";
        for(unsigned i = 0; i < xw.size(); i++)
            fout << xw[i] << " ";
        fout << endl;

        fout << "knight " << mw.size() <<" ";
        for(unsigned i = 0; i < mw.size(); i++)
            fout << mw[i] << " ";
        fout << endl;

        fout << "pawn " << bw.size() <<" ";
        for(unsigned i = 0; i < bw.size(); i++)
            fout << bw[i] << " ";
        fout << endl;

        //BLACKBLACKBLACK!!!!!!!!!!
        fout << "black\n";
        fout << "king " << wb.size() <<" ";
        for(unsigned i = 0; i < wb.size(); i++)
            fout << wb[i] << " ";
        fout << endl;

        fout << "queen " << hb.size() <<" ";
        for(unsigned i = 0; i < hb.size(); i++)
            fout << hb[i] << " ";
        fout << endl;

        fout << "rook " << cb.size() <<" ";
        for(unsigned i = 0; i < cb.size(); i++)
            fout << cb[i] << " ";
        fout << endl;

        fout << "bishop " << xb.size() <<" ";
        for(unsigned i = 0; i < xb.size(); i++)
            fout << xb[i] << " ";
        fout << endl;

        fout << "knight " << mb.size() <<" ";
        for(unsigned i = 0; i < mb.size(); i++)
            fout << mb[i] << " ";
        fout << endl;

        fout << "pawn " << bb.size() <<" ";
        for(unsigned i = 0; i < bb.size(); i++)
            fout << bb[i] << " ";
        fout << endl;
    }
    else {
        //BLACKBLACKBLACK!!!!!!!!!!
        fout << "black\n";
        fout << "king " << wb.size() <<" ";
        for(unsigned i = 0; i < wb.size(); i++)
            fout << wb[i] << " ";
        fout << endl;

        fout << "queen " << hb.size() <<" ";
        for(unsigned i = 0; i < hb.size(); i++)
            fout << hb[i] << " ";
        fout << endl;

        fout << "rook " << cb.size() <<" ";
        for(unsigned i = 0; i < cb.size(); i++)
            fout << cb[i] << " ";
        fout << endl;

        fout << "bishop " << xb.size() <<" ";
        for(unsigned i = 0; i < xb.size(); i++)
            fout << xb[i] << " ";
        fout << endl;

        fout << "knight " << mb.size() <<" ";
        for(unsigned i = 0; i < mb.size(); i++)
            fout << mb[i] << " ";
        fout << endl;

        fout << "pawn " << bb.size() <<" ";
        for(unsigned i = 0; i < bb.size(); i++)
            fout << bb[i] << " ";
        fout << endl;


        //WHITEWHITEWHITE!!!!!!!!!!

        fout << "white\n";
        fout << "king " << ww.size() <<" ";
        for(unsigned i = 0; i < ww.size(); i++)
            fout << ww[i] << " ";
        fout << endl;

        fout << "queen " << hw.size() <<" ";
        for(unsigned i = 0; i < hw.size(); i++)
            fout << hw[i] << " ";
        fout << endl;

        fout << "rook " << cw.size() <<" ";
        for(unsigned i = 0; i < cw.size(); i++)
            fout << cw[i] << " ";
        fout << endl;

        fout << "bishop " << xw.size() <<" ";
        for(unsigned i = 0; i < xw.size(); i++)
            fout << xw[i] << " ";
        fout << endl;

        fout << "knight " << mw.size() <<" ";
        for(unsigned i = 0; i < mw.size(); i++)
            fout << mw[i] << " ";
        fout << endl;

        fout << "pawn " << bw.size() <<" ";
        for(unsigned i = 0; i < bw.size(); i++)
            fout << bw[i] << " ";
        fout << endl;

    }
}
bool checkTwo()
{
    bool t1 = (a[2][8].type == 'h');
    bool t2 = false;
    bool t3 = (a[1][3].type == 'x');

//    if(a[Tempb][3].type = 'b' && a[Tempb + 1][3].type == 'b')
//        t1 = true;
    if(a[tx][ty].type == 'b' && a[tx + 1][ty].type == 'b')
        t2 = true;
    return (t1 && t2 && t3);

}
void MainWindow::initServer()
{
    this->listenSocket = new QTcpServer;
    this->listenSocket->listen(QHostAddress::Any, 8888);
    QObject::connect(this->listenSocket, SIGNAL(newConnection()), this, SLOT(acceptConnection()));
}

void MainWindow::connectHost()
{
    this->readWriteSocket = new QTcpSocket;
    Clinet *cli = new Clinet(this);
    cli->show();
    QString HostAdr;
    if(cli->exec()){
        HostAdr = cli->getAdr();
    }
    this->readWriteSocket->connectToHost(QHostAddress(HostAdr), 8888);
//    this->readWriteSocket->connectToHost(QHostAddress("172.30.95.38"), 8888);
    QObject::connect(this->readWriteSocket, SIGNAL(readyRead()), this, SLOT(revData()));
//    QMessageBox::information(this, "Connected to server", "Connected to server");
}

void MainWindow::acceptConnection()
{
    mySide = 'w';
    this->readWriteSocket = this->listenSocket->nextPendingConnection();
    QObject::connect(this->readWriteSocket, SIGNAL(readyRead()), this, SLOT(revData()));
    QMessageBox::information(this, "A clinet con", "Client connected");
    sendData("connected");
    timer->start(1000);
}

//0 means go on, 1 means failure
void MainWindow::sendData(QString ins)
{
//    checkMyKing();
    QString data;
    if(ins == ""){
        data += "0";
    }
    else if(ins == "fail"){
        data += "F";
    }
    else if(ins == "win"){
        data += "W";
    }
    else if(ins == "e"){
        data += "E";
    }
    else if(ins == "connected"){
        data +="C";
    }
    else{
        data += "U";
    }
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            QString temp = "\0\0";
            temp[0] = a[i][j].type;
            temp[1] = (a[i][j].isWhite ? 'w' : 'b');
            data += temp;
        }
    }
//    cout << "DATA\n" << data.toStdString();
    QByteArray *arr = new QByteArray;
    arr->clear();
    arr->append(data);
    this->readWriteSocket->write(arr->data());
//    qDebug() << "Send" << endl << data;
}

void MainWindow::revData()
{
//    timer->setInterval(5000);
//    timer->start(1000); // 1000毫秒, 等于 1 秒
//    myTurn = true;
//    checkYourKing();
//    checkMyKing();

    myTurn = true;
    //ADDEDADDEDADDED
    timeLeft = TIME_LIMIT;
    timer->start(1000);
    //

    QString info;
    info = this->readWriteSocket->readAll();
    string cliRevData = info.toStdString().substr(1, info.toStdString().size());
    for(int i = 0; i < 9; i++)
        for(int j = 0 ; j < 9; j++){
            a[i][j].type = char(cliRevData[i * 18 + j * 2]);
            a[i][j].isWhite = (cliRevData[i * 18 + j * 2 + 1] == 'w' ? true : false);
        }
    this->repaint();
    if(info[0] == 'F'){
        QMessageBox::information(this, "YOU WIN", "GREAT, YOU WIN!!");
    }
    else if(info[0] == 'W'){
        QMessageBox::information(this, "YOU LOSE", "SORRY, YOU LOSE!!");
    }
    else if(info[0] == '0'){
        return;
    }
    else if(info[0] == 'E'){
        QMessageBox::information(this, "Exchanged", "The rival has Exchanged King and Rook");
    }
    else if(info[0] == 'C'){
        QMessageBox::information(this, "Connected", "Connected");
    }
    else {
        QMessageBox::information(this, "Unknow", "In rev...");
    }
}

void MainWindow::on_actionServer_triggered()
{
    this->setWindowTitle("Server");
    this->listenSocket = new QTcpServer;
    this->listenSocket->listen(QHostAddress::Any, 8888);

    QString ServerIPV4;
    QString localHostName = QHostInfo::localHostName();
    QHostInfo info = QHostInfo::fromName(localHostName);

    foreach(QHostAddress address,info.addresses())
    {
        if(address.protocol() == QAbstractSocket::IPv4Protocol)
             ServerIPV4 =  address.toString();
    }
    Server *ser = new Server(this);
    ser->setLine(ServerIPV4);
    ser->show();

    QObject::connect(this->listenSocket, SIGNAL(newConnection()), this, SLOT(acceptConnection()));
}

void MainWindow::on_actionClinet_triggered()
{
    this->setWindowTitle("Clinet");
    this->connectHost();
}

void MainWindow::on_pushLosed_clicked()
{
    sendData("fail");
    QMessageBox::information(this, "YOU LOSE", "SORRY, YOU LOSE!!");
}

void MainWindow::on_pushCancelConn_clicked()
{
    listenSocket->close();
    this->ui->labelStatus->setText("Disconnected");
    QMessageBox::information(this, "Cancelled", "The Connection is cancelled");
}
void MainWindow::updateTime()
{
    timeLeft--;
    this->ui->lcdNumber->display(timeLeft);
    if(timeLeft == 0){
        timer->stop();
        sendData("fail");
        QMessageBox::information(this, "Time Out", "Sorry, Time is out.\nYou Lose");
    }
}
//void MainWindow::closeListen()
//{
//    this->listenSocket->close();
//}
//void MainWindow::checkMyKing()
//{
//    bool haveKing = false;
//    bool iAmWhiteside = (mySide == 'w' ? true : false);
//    for(int i =1; i < 9; i++)
//        for(int j = 1; j < 9; j++)
//            if(a[i][j].type == 'w' && a[i][j].isWhite == iAmWhiteside){
//                haveKing = true;
//                break;
//            }
//    if(!haveKing){
//        sendData("fail");
//        QMessageBox::information(this, "LOSE", "Sorry, your King is eaten.\nYou Lose");
//        exit(0);
//    }
//}

void MainWindow::checkMyKing()
{
    bool youHaveKing = false;
    bool yourSideIsWhite = (mySide == 'w' ? false : true);
    for(int i =1; i < 9; i++)
        for(int j = 1; j < 9; j++)
            if( a[i][j].type == 'w' && ( (a[i][j].isWhite && yourSideIsWhite)||(!a[i][j].isWhite && !yourSideIsWhite) ) ){
                youHaveKing = true;
                break;
            }
    if(!youHaveKing){
        sendData("win");
        QMessageBox::information(this, "WIN", "Congratulations!\nYou Win");
    }
}


void MainWindow::on_pushExchange_clicked()
{
    valid[5] = true;
    valid[6] = true;
    valid[7] = true;
    valid[8] = true;
    int i = 2;
    for(i = 1 + 1; i < 9; i++)
        if( (a[i][5].type == 'c' || a[i][5].type =='h') && !a[i][5].isWhite){
            valid[5] = false;
            break;
        }
    for(int j = 2; j < i; j++)
        if(a[j][5].type != 'k' && a[j][5].isWhite)
            valid[5] = true;
//

    for(i = 1 + 1; i < 9; i++)
        if( (a[i][6].type == 'c' || a[i][6].type =='h') && !a[i][6].isWhite){
            valid[6] = false;
            break;
        }
    for(int j = 2; j < i; j++)
        if(a[j][6].type != 'k' && a[j][6].isWhite)
            valid[6] = true;
//
    for(i = 1 + 1; i < 9; i++)
        if( (a[i][7].type == 'c' || a[i][7].type =='h') && !a[i][7].isWhite){
            valid[7] = false;
            break;
        }
    for(int j = 2; j < i; j++)
        if(a[j][7].type != 'k' && a[j][7].isWhite)
            valid[7] = true;
    //
        for(i = 1 + 1; i < 9; i++)
            if( (a[i][8].type == 'c' || a[i][8].type =='h') && !a[i][8].isWhite){
                valid[8] = false;
                break;
            }
        for(int j = 2; j < i; j++)
            if(a[j][8].type != 'k' && a[j][8].isWhite)
                valid[8] = true;

    if(!(valid[5]&&valid[6]&&valid[7]&&valid[8])){
        QMessageBox::information(this, "Not Valid", "It is not valid");
        return;
    }
    else if(a[1][5].type == 'w' && a[1][5].isWhite && a[1][8].type == 'c' && a[1][8].isWhite){
        for(int i = 6; i < 8; i++){
            if(a[1][i].type != 'k'){
                QMessageBox::information(this, "NO EXCHANGE", "BLOCKED");
                return;
            }
        }
        a[1][5].type = 'k';
        a[1][6].type = 'c'; a[1][6].isWhite = true;
        a[1][7].type = 'w'; a[1][7].isWhite = true;
        a[1][8].type = 'k';
        this->repaint();
        sendData("e");
    }
//    sendData("e");
}
void MainWindow::on_pushExchange_2_clicked()
{
    valid[1] = true;
    valid[2] = true;
    valid[3] = true;
    valid[4] = true;
    valid[5] = true;
    bool good = true;

    int i = 2;
    for(int loop =1; loop <6; loop++){
        for(i = 1 + 1; i < 9; i++)
            if( (a[i][loop].type == 'c' || a[i][loop].type =='h') && !a[i][loop].isWhite){
                valid[loop] = false;
                break;
            }
        for(int j = 2; j < i; j++)
            if(a[j][loop].type != 'k' && a[j][loop].isWhite)
                valid[loop] = true;
    }
    for(int c = 1; c < 6; c++)
        good = good&&valid[c];

    if(!good){
        QMessageBox::information(this, "Not Valid", "It is not valid");
        return;
    }
    else if(a[1][5].type == 'w' && a[1][5].isWhite && a[1][1].type == 'c' && a[1][1].isWhite){
        for(int i = 2; i < 5; i++){
            if(a[1][i].type != 'k'){
                QMessageBox::information(this, "NO EXCHANGE", "BLOCKED");
                return;
            }
        }
        a[1][1].type = 'k';
        a[1][2].type = 'k';
        a[1][3].type = 'w'; a[1][3].isWhite = true;
        a[1][4].type = 'c'; a[1][4].isWhite = true;
        a[1][5].type = 'k';
        this->repaint();
        sendData("e");
    }
//    sendData("e");
}

void MainWindow::on_pushExchange_3_clicked()
{
    if(a[8][5].type == 'w' && !a[8][5].isWhite && a[8][8].type == 'c' && !a[8][8].isWhite){
        for(int i = 6; i < 8; i++){
            if(a[8][i].type != 'k'){
                QMessageBox::information(this, "NO EXCHANGE", "BLOCKED");
                return;
            }
        }
        a[8][5].type = 'k';
        a[8][6].type = 'c'; a[1][6].isWhite = false;
        a[8][7].type = 'w'; a[1][7].isWhite = false;
        a[8][8].type = 'k';
        this->repaint();
        sendData("e");
    }
//    sendData("e");
}

void MainWindow::on_pushExchange_4_clicked()
{
    if(a[8][5].type == 'w' && !a[8][5].isWhite && a[8][1].type == 'c' && !a[8][1].isWhite){
        for(int i = 2; i < 5; i++){
            if(a[8][i].type != 'k'){
                QMessageBox::information(this, "NO EXCHANGE", "BLOCKED");
                return;
            }
        }
        a[8][1].type = 'k';
        a[8][2].type = 'k';
        a[8][3].type = 'w'; a[1][3].isWhite = true;
        a[8][4].type = 'c'; a[1][4].isWhite = true;
        a[8][5].type = 'k';
        this->repaint();
        sendData("e");
    }
//    sendData("e");
}
bool checkOne()
{
    bool doubleCheck = (a[2][1].type == 'k');
    if(a[8][8].type == 'w' && !a[8][8].isWhite){
        for(int i = 1; i < 8; i++)
            if((a[8][i].type == 'h'||a[8][i].type == 'c') && (!a[8][i].isWhite))
                return (doubleCheck && true);
    }
    else
        return false;
}
//void MainWindow::highLight(int x, int y)
//{
//    cout << "HIGH" << endl;
//    bool h[9][9] = {{0}};
//    Point src, dst;
//    src.x = x; src.y = y;
//    bool isValid = true;

//    for(int i = 1; i < 9; i++)
//        for(int j = 1; j < 9; j++){
//            if(a[src.x][src.y].type == 'b'){
//                if(a[src.x][src.y].isWhite){
//                    //WHITE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//                    if(src.x == 2){
//                        if(dst.x == src.x +1){
//                            if( abs(dst.y - src.y) == 1 ){
////                                if( (a[src.x + 1][src.y - 1].type !='k' && !a[src.x + 1][src.y - 1].isWhite) || (a[src.x + 1][src.y + 1].type !='k' && !a[src.x + 1][src.y + 1].isWhite) );
//                                if( (a[dst.x][src.y - 1].type !='k' && !a[dst.x][src.y - 1].isWhite) || (a[dst.x][src.y + 1].type !='k' && !a[dst.x][src.y + 1].isWhite) )
//                                    isValid = true;
//                                else
//                                    isValid = false;
//                            }
//                            //后改的！！
//                            else if(dst.y == src.y && a[dst.x][dst.y].type == 'k')
//                                isValid = true;
//                            else {
//                                isValid = false;
//                            }
//                        }
//                        else if(dst.x == src.x + 2){
////                            if(a[src.x + 2] [dst.y].type == 'k');
//                            if(a[dst.x] [dst.y].type == 'k' && dst.y == src.y)
//                                isValid = true;
//                            else {
//                                isValid = false;
//                            }
//                        }
//                        //x 方向移动>=3
//                        else {
//                            isValid = false;
//                        }

//                    }
//                    else if(src.x == 7){
//                        if(dst.x != src.x + 1)
//                            isValid = false;
//                        else if( (dst.y == src.y && a[dst.x][dst.y].type == 'k') || (dst.y == src.y+1 && a[dst.x][dst.y].type != 'k') || (dst.y == src.y-1 && a[dst.x][dst.y].type != 'k') ){
//                            isValid = true;
//                        }
//                        else {
//                            isValid = false;
//                        }
//                    }
//                    else if(src.x > 2 && src.x < 7){
//                        if(dst.x != src.x + 1){
//                            isValid = false;
//                        }
//                        else {
//                            if(dst.y == src.y){
//                                if(a[dst.x][dst.y].type == 'k')
//                                    isValid = true;
//                                else
//                                    isValid = false;
//                            }
//                            else if(abs(dst.y - src.y) == 1){
//                                if(a[dst.x][dst.y].type != 'k'){
//                                    isValid = true;
//                                }
//                                else{
//                                    isValid = false;
//                                    cout << "HIGHLIGHT 1 PROBLEM" << endl;
//                                }
//                            }
//                            else {
//                                cout << "WRONG IN WHITE HIGHLIGHT LINE 3 to 6" << endl;
//                            }
//                        }
//                    }
//                    else{
//                        cout << "HIGHLIGHT SOMETHING WRONG IN PAWN... WHITE PART" << endl;
//                    }
//                }
int sCheck()
{
    return (checkOne() || checkTwo());
}

//                //BLACK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//                else {
//                    if(src.x == 7){
//                        if(dst.x == src.x -1){
//                            if( abs(dst.y - src.y) == 1 ){
//                                if( (a[dst.x][src.y - 1].type !='k' && a[dst.x][src.y - 1].isWhite) || (a[dst.x][src.y + 1].type !='k' && a[dst.x][src.y + 1].isWhite) )
//                                   if( (a[src.x - 1][src.y - 1].type !='k' && !a[src.x - 1][src.y - 1].isWhite) || (a[src.x - 1][src.y + 1].type !='k' && !a[src.x - 1][src.y + 1].isWhite) )
//                                    isValid = true;
//                                else
//                                    isValid = false;
//                            }
//                            else if(dst.y == src.y)
//                                isValid = true;
//                            else {
//                                isValid = false;
//                            }
//                        }
//                        else if(dst.x == src.x - 2){
//                            if(a[dst.x] [dst.y].type == 'k' && dst.y == src.y)
//                                isValid = true;
//                            else {
//                                isValid = false;
//                            }
//                        }
//                        //x 方向移动>=3
//                        else {
//                            isValid = false;
//                        }

//                    }
//                    else if(src.x == 2){
//                        if(dst.x != src.x - 1)
//                            isValid = false;
//                        else if( (dst.y == src.y && a[dst.x][dst.y].type == 'k') || (dst.y == src.y+1 && a[dst.x][dst.y].type != 'k') || (dst.y == src.y-1 && a[dst.x][dst.y].type != 'k') ){
//                            isValid = true;
//                        }
//                        else {
//                            isValid = false;
//                        }
//                    }
//                    else if(src.x > 2 && src.x < 7){

//                        if(dst.x != src.x - 1){
//                            isValid = false;
//                        }

//                        else {
//                            if(dst.y == src.y){
//                                if(a[dst.x][dst.y].type == 'k')
//                                    isValid = true;
//                                else
//                                    isValid = false;
//                            }
//                            else if(abs(dst.y - src.y) == 1){
//                                if(a[dst.x][dst.y].type != 'k'){
//                                    isValid = true;
//                                }
//                                else{
//                                    isValid = false;
//                                    qDebug() << tr("HIGHLIGHT 2 PROBLEM") << endl;
//                                }
//                            }
//                            else {
//                                cout << "HIGHLIGHT WRONG IN WHITE LINE 3 to 6" << endl;
//                            }
//                        }
//                    }
//                    else{
//                        cout << "SOMETHING WRONG IN PAWN... WHITE PART" << endl;
//                    }

//                }
//            }



//            if(isValid){
//                h[i][j] = true;
//            }
//        }
//    QPainter p(this);
//    p.translate(40, 40);
//    for (int i = 1; i < 9; ++i) {
//        for (int j = 1; j < 9; j++) {
//            if(h[i][j]){
//                p.setBrush(Qt::yellow);
//                p.drawRect((i - 1) * 40, (j - 1) * 40, 40, 40);
//            }
//        }
//    }
//}

