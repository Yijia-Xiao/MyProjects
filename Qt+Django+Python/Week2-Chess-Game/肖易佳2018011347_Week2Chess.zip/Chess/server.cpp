#include "server.h"
#include "ui_server.h"
#include "connecting.h"

Server::Server(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);

}

Server::~Server()
{
    delete ui;
}

void Server::setLine(QString serAdr)
{
    ui->lineServerAddr->setText(serAdr);
}

void Server::on_buttonBox_accepted()
{
    connecting *con = new connecting(this);
    con->show();
}
