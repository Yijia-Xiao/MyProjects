#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "headers.h"
#include "prob.h"
#include "server.h"
#include "clinet.h"
#include "savelog.h"
#include "connecting.h"
namespace Ui {
class MainWindow;
}

class Grid
{
public:
    bool isWhite = true;
    char type = 'k';
};

class Point
{
public:
    int x = 0;
    int y = 0;
    Point(int nX = 0, int nY = 0){x = nX; y = nY;}
};


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *mevent);
    void init();
    void load();
    void clear();
    void checkMyKing();
//    void checkYourKing();
    //TCP
    void initServer();
    void connectHost();
//    static void closeListen();
//    bool isThreatened(Point src, Point dst);
//    QPainter *p;
//    void highLight(int x, int y);
//    void mouseClickEvent(QMouseEvent *m);

    //TCP
public slots:
    void acceptConnection();
    void revData();
    void updateTime();


//    void temp(){
//        qDebug() << 666 << endl;
//    }
//TCP
signals:
    void moved();

private slots:
    void on_actionLoadaGame_triggered();

    void on_actionSaveGame_triggered();

    void on_actionNewGame_triggered();

    void on_actionServer_triggered();

    void on_actionClinet_triggered();
//TCP
    void sendData(QString ins = "");

    void on_pushLosed_clicked();

    void on_pushCancelConn_clicked();

    void on_pushExchange_clicked();

    void on_pushExchange_2_clicked();

    void on_pushExchange_3_clicked();

    void on_pushExchange_4_clicked();

private:
    Ui::MainWindow *ui;
    QTimer *timer;
    //TCP
    QTcpServer *listenSocket;
    QTcpSocket *readWriteSocket;
    connecting *con;

};


#endif // MAINWINDOW_H
