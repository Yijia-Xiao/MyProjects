#ifndef SAVELOG_H
#define SAVELOG_H

#include <QDialog>
#include <QString>
namespace Ui {
class SaveLog;
}

class SaveLog : public QDialog
{
    Q_OBJECT

public:
    explicit SaveLog(QWidget *parent = nullptr);
    ~SaveLog();
    QString savePath();

private:
    Ui::SaveLog *ui;
};

#endif // SAVELOG_H
