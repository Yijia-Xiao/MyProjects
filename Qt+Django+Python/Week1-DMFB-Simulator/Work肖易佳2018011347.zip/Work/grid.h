#ifndef GRID_H
#define GRID_H
#include "headers.h"
#include "waterdrop.h"
#include <string>
#include <iostream>
using namespace std;
#define SIZE 15

class Grid
{
public:
    int type_drop = 0;
    bool occupied = false;
    bool streched = false;
    bool shuZhi = false;
    set<int> pollutedTimes;
    Point pos = Point(0, 0);

    //    bool checkValid();
};

class Map
{
public:
    Grid grids[SIZE][SIZE];
//    static bool manipulation(string, string); // if succeed return true;
};

#endif // GRID_H
