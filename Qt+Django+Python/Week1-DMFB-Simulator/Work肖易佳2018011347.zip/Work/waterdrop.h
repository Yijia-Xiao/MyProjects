#ifndef WATERDROP_H
#define WATERDROP_H
#include "headers.h"
using namespace std;

class Point
{
public:
    int x = 0;
    int y = 0;
    Point(int new_x = 0, int new_y = 0){
        x = new_x;
        y = new_y;
    }
};

class Drop
{
public:
    Point pos;
    int type = 0;//
    bool opearated = false;
    bool longing = false;
    bool shuZhi = true;//
};
class DropVector
{
public:
    vector<Drop> dropvector;
};

#endif // WATERDROP_H
