#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "headers.h"
#include "dialog.h"
#include "waterdrop.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Dialog * init;
    DataPack initer;
    static vector<string> cmd;
    static vector<string> data;
    void paintEvent(QPaintEvent *event);
//    void drawElli();

//        int time_w = 0;
//        int time_dur_w = 0;
//    check the validity at TIME 't'
//    void manipulation(MainWindow & w);
//    QString path;
//    bool fileChosen = false;
//    void draw(int t, QPaintEvent *pe = nullptr);
//    void paintEvent(QPaintEvent *event);


signals:
    void dataReady();

public slots:
    void manipulation();
    bool isValid();
//    void drawDrops(int t);
private slots:
    void on_buttonNew_clicked();
    void receive_Init_DataPack(DataPack receive_Ini);

    void on_buttonPlay_clicked();

    void on_buttonPre_clicked();

    void on_bunttonNex_clicked();

    void on_pushButton_5_clicked();

    void on_buttonCheck_clicked();

    void on_buttonpol_clicked();

    void on_buttonPau_clicked();

private:
    Ui::MainWindow *ui;
};
int dist(Point, Point);



#endif // MAINWINDOW_H

//class Draw
//{
//public:
//    QPainter *p;
//    void drawBack(int row, int col);
//    void circle(int time, int x, int y, int type);
//};
