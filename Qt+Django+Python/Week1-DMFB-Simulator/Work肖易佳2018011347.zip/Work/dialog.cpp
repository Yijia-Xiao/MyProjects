#include "dialog.h"
#include "ui_dialog.h"
#include <QFileDialog>
#include <QMessageBox>
#include <string>
#include <cstring>
#include <QVBoxLayout>

#include "mainwindow.h"
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_add_input_clicked()
{
    dp.input_x.push_back(ui->input_row->value());
    dp.input_y.push_back(ui->input_col->value());
    string current;
    for(int i = 0; i < dp.input_x.size(); i++){
        current += "(";
        current += to_string(dp.input_x[i]);
        current += ", ";
        current += to_string(dp.input_y[i]);
        current += "); ";
    }
    QString qs = QString::fromStdString(current);
    ui->curr->setText(qs);
}


void Dialog::on_enter_path_clicked()
{
    QFileDialog *fileDialog = new QFileDialog(this);
    fileDialog->setWindowTitle(tr("Open InputFile"));
    fileDialog->setNameFilter(tr("*.txt"));
    QString qpath;
    if(fileDialog->exec() == QDialog::Accepted) {
            qpath = fileDialog->selectedFiles()[0];
            QMessageBox::information(nullptr, tr("Path"), tr("You selected ") + qpath);
            chosen = true;
    } else {
            QMessageBox::information(nullptr, tr("Path"), tr("You didn't select any files."));
    }
    pathFromDialog = qpath;
}

void Dialog::on_buttonBox_accepted()
{
    dp.rows = ui->spin_row->value();
    dp.cols = ui->spin_col->value();
    dp.output_x = ui->output_row->value();
    dp.output_y = ui->output_col->value();
    dp.path_DataPack = Dialog::pathFromDialog;
    dp.isChosen = chosen;
    emit send_Init_DataPack(dp);
}

void Dialog::on_checkRow_clicked()
{
    int row = this->ui->spin_row->value();
    if(row < 3)
        QMessageBox::information(nullptr, "Row Error", "ROW < 3\nPlease Check!", QMessageBox::Ok, QMessageBox::Ok);
    else {
        QMessageBox::information(nullptr, "Good", "ROW >= 3\nIt is Okay!", QMessageBox::Ok, QMessageBox::Ok);
    }
}

void Dialog::on_checkCol_clicked()
{
    int col = this->ui->spin_col->value();
    if(col < 3)
        QMessageBox::information(nullptr, "Col Error", "COL < 3\nPlease Check!", QMessageBox::Ok, QMessageBox::Ok);
    else {
        QMessageBox::information(nullptr, "Good", "COL >= 3\nIt is Okay!", QMessageBox::Ok, QMessageBox::Ok);
    }
}
