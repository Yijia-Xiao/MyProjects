#include "ui_mainwindow.h"
#include "headers.h"
#include "grid.h"
#include <QPoint>
#include <QTimer>
#include <QElapsedTimer>
#include <QSoundEffect>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "headers.h"
#include "grid.h"
#include <QPoint>
#include <QTimer>
#include <QElapsedTimer>
using namespace std;
#define TIME 105
#define SIZE 15

static int typenum = 0;
static Map m[TIME];
static vector<Point> inputs;

static DropVector drops[TIME];
static Point output = Point(-2.-2);
static int row = SIZE, col = SIZE;
static int time_curr = 0;
static int time_max = 0;
static bool out_inied = false;
static bool pause = false;
static vector<int> sounds[TIME]; //1 move mix 2 merge 3 splitlong 4 split short
using namespace std;
static QSoundEffect s1, s2, s3, s4, s5;
int dist(int a,int b,int c,int d)
{
    return (a-c)*(a-c)+(b-d)*(b-d);
}
MainWindow::MainWindow(QWidget *parent):
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setPen(Qt::blue);
    p.translate(50, 50);
    for(int i = 1; i <= this->initer.rows; i++)
        for(int j = 1; j <= this->initer.cols; j++)
            p.drawRect(i * 50, j * 50, 50, 50);

    for(int i = 0; i < inputs.size(); i++){
            p.setBrush(Qt::red);
            if(inputs[i].x==0){
                p.drawRect((inputs[i].x) * 50, inputs[i].y * 50, 50, 50);
               }
            else if(inputs[i].x==this->initer.rows+1){
                p.drawRect((inputs[i].x) * 50, inputs[i].y * 50, 50, 50);
            }
            else{
                if(inputs[i].y==0){
                    if(inputs[i].x!=0&&inputs[i].x!=this->initer.rows+1)
                        p.drawRect((inputs[i].x) * 50, (inputs[i].y) * 50, 50, 50);
                }
                else if(inputs[i].y==this->initer.cols+1){
                    if(inputs[i].x!=0&&inputs[i].x!=this->initer.rows+1)
                        p.drawRect((inputs[i].x) * 50, (inputs[i].y) * 50, 50, 50);
                }
                else{
                    //QMessageBox::warning(this,"Input invalid","Input not on the border",QMessageBox::Ok|QMessageBox::No);
                }
            }
        }
        p.setBrush(Qt::green);
        if(out_inied){
            if(output.x==0){
                p.drawRect((output.x) * 50, output.y * 50, 50, 50);
               }
            else if(output.x==this->initer.rows+1){
                p.drawRect((output.x) * 50, output.y * 50, 50, 50);
            }
            else{
                if(output.y==0){
                    if(output.x!=0&&output.x!=this->initer.rows+1)
                        p.drawRect((output.x) * 50, (output.y) * 50, 50, 50);
                }
                else if(output.y==this->initer.cols+1){
                    if(output.x!=0&&output.x!=this->initer.rows+1)
                        p.drawRect((output.x) * 50, (output.y) * 50, 50, 50);
                }
                else{
                    //QMessageBox::warning(this,"Output invalid","Output not on the border",QMessageBox::Ok|QMessageBox::No);
                }
            }
        }
    for(int i=1;i<=this->initer.rows;i++){
        for(int j=1;j<=this->initer.cols;j++){
            p.setPen(Qt::black);
            p.drawText(i*50+25,j*50+25,QString::number(m[time_curr].grids[i][j].pollutedTimes.size()));
        }
    }
    for (int i =1; i <= this->initer.rows; i++) {
        for(int j=1;j<=this->initer.cols;j++){
            if(m[time_curr].grids[i][j].occupied){
                if(m[time_curr].grids[i][j].type_drop==1){
                    p.setBrush((Qt::blue));
                }
                if(m[time_curr].grids[i][j].type_drop==2){
                    p.setBrush((Qt::black));
                }
                if(m[time_curr].grids[i][j].type_drop==3){
                    p.setBrush((Qt::red));
                }
                if(m[time_curr].grids[i][j].type_drop==4){
                    p.setBrush((Qt::gray));
                }
                if(m[time_curr].grids[i][j].type_drop==5){
                    p.setBrush((Qt::yellow));
                }
                if(m[time_curr].grids[i][j].type_drop==6){
                    p.setBrush((Qt::white));
                }
                if(m[time_curr].grids[i][j].type_drop>=7){
                    p.setBrush((Qt::cyan));
                }
                if(!m[time_curr].grids[i][j].streched){
                    //cout<<m[time_curr].grids[i][j].pos.x<<" "<<m[time_curr].grids[i][j].pos.y<<endl;
                    //p.drawEllipse(m[time_curr].grids[i][j].pos.x * 50, m[time_curr].grids[i][j].pos.y * 50, 50, 50);
                    p.drawEllipse(i * 50, j * 50, 50, 50);
                }
                else{
                    if(m[time_curr].grids[i][j].shuZhi){
                        p.drawEllipse(i*50,(j-1)*50,50,150);
                    }
                    else{
                        p.drawEllipse((i-1)*50,j*50,150,50);
                    }
                }
            }
        }
    }
}
//void MainWindow::paintEvent(QPaintEvent *)
//{
//    QPainter p(this);
//    p.setPen(Qt::blue);
//    p.translate(50, 50);
//    for(int i = 1; i <= this->initer.rows; i++)
//        for(int j = 1; j <= this->initer.cols; j++)
//            p.drawRect(i * 50, j * 50, 50, 50);

//    for(int i = 0; i < inputs.size(); i++){
//        p.setBrush(Qt::red);
//        if(inputs[i].x==1){
//            p.drawRect((inputs[i].x-1) * 50, inputs[i].y * 50, 50, 50);
//           }
//        else if(inputs[i].x==this->initer.rows){
//            p.drawRect((inputs[i].x+1) * 50, inputs[i].y * 50, 50, 50);
//        }
//        else{
//            if(inputs[i].y==1){
//                if(inputs[i].x!=1&&inputs[i].x!=this->initer.rows)
//                    p.drawRect((inputs[i].x) * 50, (inputs[i].y-1) * 50, 50, 50);
//            }
//            else if(inputs[i].y==this->initer.cols){
//                if(inputs[i].x!=1&&inputs[i].x!=this->initer.rows)
//                    p.drawRect((inputs[i].x) * 50, (inputs[i].y+1) * 50, 50, 50);
//            }
//            else{
//                QMessageBox::warning(this,"Input Port invalid","Input Port not on the border",QMessageBox::Ok, QMessageBox::Ok);
//            }
//        }
//    }
//    if(out_inied){
//        p.setBrush(Qt::green);
//        cout<<output.x<<" "<<output.y<<endl;
//        if(output.x==1){
//            p.drawRect((output.x-1) * 50, output.y * 50, 50, 50);
//           }
//        else if(output.x==this->initer.rows){
//            p.drawRect((output.x+1) * 50, output.y * 50, 50, 50);
//        }
//        else{
//            if(output.y==1){
//                if(output.x!=1&&output.x!=this->initer.rows)
//                    p.drawRect((output.x) * 50, (output.y-1) * 50, 50, 50);
//            }
//            else if(output.y==this->initer.cols){
//                if(output.x!=1&&output.x!=this->initer.rows)
//                    p.drawRect((output.x) * 50, (output.y+1) * 50, 50, 50);
//            }
//            else{
//                QMessageBox::warning(this,"Out Port invalid","Output Port not on the border",QMessageBox::Ok, QMessageBox::Ok);
//            }
//        }
//    }
//    for(int i=1;i<=this->initer.rows;i++){
//        for(int j=1;j<=this->initer.cols;j++){
//            p.setPen(Qt::black);
//            p.drawText(i*50+25,j*50+25,QString::number(m[time_curr].grids[i][j].pollutedTimes));
//        }
//    }
//    for (int i =1; i <= this->initer.rows; i++) {
//        for(int j=1;j<=this->initer.cols;j++){
//            if(m[time_curr].grids[i][j].occupied){
//                if(m[time_curr].grids[i][j].type_drop==1){
//                    p.setBrush((Qt::blue));
//                }
//                if(m[time_curr].grids[i][j].type_drop==2){
//                    p.setBrush((Qt::black));
//                }
//                if(m[time_curr].grids[i][j].type_drop==3){
//                    p.setBrush((Qt::red));
//                }
//                if(m[time_curr].grids[i][j].type_drop==4){
//                    p.setBrush((Qt::gray));
//                }
//                if(m[time_curr].grids[i][j].type_drop==5){
//                    p.setBrush((Qt::yellow));
//                }
//                if(m[time_curr].grids[i][j].type_drop==6){
//                    p.setBrush((Qt::white));
//                }
//                if(m[time_curr].grids[i][j].type_drop>=7){
//                    p.setBrush((Qt::cyan));
//                }
//                if(!m[time_curr].grids[i][j].streched){
//                    //cout<<m[time_curr].grids[i][j].pos.x<<" "<<m[time_curr].grids[i][j].pos.y<<endl;
//                    //p.drawEllipse(m[time_curr].grids[i][j].pos.x * 50, m[time_curr].grids[i][j].pos.y * 50, 50, 50);
//                    p.drawEllipse(i * 50, j * 50, 50, 50);
//                }
//                else{
//                    if(m[time_curr].grids[i][j].shuZhi){
//                        p.drawEllipse(i*50,(j-1)*50,50,150);
//                    }
//                    else{
//                        p.drawEllipse((i-1)*50,j*50,150,50);
//                    }
//                }
//            }
//        }
//    }
//}
void MainWindow::on_buttonNew_clicked()
{
    s1.setSource(QUrl::fromLocalFile("C:\\Users\\TsinghuaXYJ\\Documents\\Work\\sounds\\move.wav"));
    s2.setSource(QUrl::fromLocalFile("C:\\Users\\TsinghuaXYJ\\Documents\\Work\\sounds\\merge.wav"));
    s3.setSource(QUrl::fromLocalFile("C:\\Users\\TsinghuaXYJ\\Documents\\Work\\sounds\\long.wav"));
    s4.setSource(QUrl::fromLocalFile("C:\\Users\\TsinghuaXYJ\\Documents\\Work\\sounds\\longFinished.wav"));
    s5.setSource(QUrl::fromLocalFile("C:\\Users\\TsinghuaXYJ\\Documents\\Work\\sounds\\cli.wav"));

    init = new Dialog;
    init->show();
    QObject::connect(MainWindow::init, SIGNAL(send_Init_DataPack(DataPack)), this, SLOT(receive_Init_DataPack(DataPack)));
}

void MainWindow::receive_Init_DataPack(DataPack receive)
{
    MainWindow::initer = receive;
    row = receive.rows;
    col = receive.cols;
    output.x = receive.output_x;
    output.y = receive.output_y;
    out_inied = true;
    for(int i = 0; i < int(receive.input_x.size()); i++){
        inputs.push_back(Point(receive.input_x[i], receive.input_y[i]));
    }
    emit MainWindow::dataReady();
}
struct Command{
    int t;
    vector<int> X;
    vector<int> Y;
    string comm;
};
bool cmp(Command a, Command b)
{
    return a.t < b.t;
}
void MainWindow::manipulation()
{
    string cmd, data;
    ifstream fin(this->init->pathFromDialog.toStdString()), fin2(this->init->pathFromDialog.toStdString());
    vector<Command> v_com;
    while(!fin.eof()){
        fin >> cmd >> data;
        data = data.substr(0, data.size() - 1);
        char *a = new char[data.size() + 1];
        strcpy(a, data.c_str());
        char * p;
        p = strtok(a, ",");
        vector<int> X; vector<int> Y;
        int t = stoi(p);
        time_max = max(time_max, t);
        p = strtok(nullptr, ",");
        while(p){
            X.push_back(stoi(p));
            p = strtok(nullptr, ",");
            Y.push_back(stoi(p));
            p = strtok(nullptr, ",");
        }
        Command new_com;
        new_com.t = t;
        new_com.comm = cmd;
        new_com.X = X;
        new_com.Y = Y;
        v_com.push_back(new_com);
    }

    sort(v_com.begin(), v_com.end(), cmp);
//    for(int i = 0; i < time_max; i ++ )
//        cout << drops[i].dropvector.size() << endl;
    for(int ctr = 0; ctr < v_com.size(); ctr++){
        string cmd;
        int t;
        vector<int> X;
        vector<int> Y;
        t = v_com[ctr].t;
        cmd = v_com[ctr].comm;
        X = v_com[ctr].X;
        Y = v_com[ctr].Y;
//        cout << ctr << " +++++++++++++++++ " << endl;
        if(cmd == "Input"){

            bool g = false;
            for(unsigned i = 0; i < unsigned(inputs.size()); i++)
                    if(dist(inputs[i].x, inputs[i].y, X[0], Y[0])==1){
                    g = true;
                    break;
                }
            if(g){
                //
                typenum ++;
                //

                m[t].grids[ X[0] ][ Y[0] ].occupied = true;
                for(int i = t; i <= time_max; i++){
                    m[i].grids[ X[0] ][ Y[0] ].occupied = true;
                    m[i].grids[ X[0] ][ Y[0] ].pollutedTimes.insert(m[t].grids[ X[0] ][ Y[0] ].type_drop);
                }
                //record the TYPE CHANGES
                Drop new_drop;
                new_drop.pos = Point(X[0], Y[0]);
                new_drop.type = typenum;
                m[t].grids[X[0]][Y[0]].type_drop=typenum;
                for(int q = t + 1; q <= time_max; q++){
                    m[q].grids[X[0]][Y[0]].type_drop=typenum;
                }

                //
                new_drop.opearated = false;
                //

                drops[t].dropvector.push_back(new_drop);
                QMessageBox::information(nullptr, "Input Okay", "The case is okay", QMessageBox::Ok, QMessageBox::Ok);
            }
            else{
                QMessageBox::critical(nullptr, "Input Error Case", "The case is error, the demo will close", QMessageBox::Ok, QMessageBox::Ok);
//                exit(0);
            }
        }

        else if(cmd == "Output"){
            if(dist(output.x, output.y, X[0], Y[0])==1){
                m[t].grids[X[0]][Y[0]].occupied = false;
                for(int i=t;i<=time_max;i++){
                    m[i].grids[ X[0] ][ Y[0] ].occupied = false;
                }
                QMessageBox::information(nullptr, "Output Okay", "The case is okay", QMessageBox::Ok, QMessageBox::Ok);
            }
            else{
                QMessageBox::critical(nullptr, "Output Error Case", "The case is error, the demo will close", QMessageBox::Ok, QMessageBox::Ok);
//                exit(0);
            }
        }
        else if(cmd == "Mix"){
            sounds[t].push_back(1);
            int my_type = typenum;
            for(int i = 1; i < int(X.size()); i++){
                m[t + i].grids[ X[i] ][ Y[i] ].occupied = true;
                for(int q=t+i;q<=time_max;q++){
                    m[q].grids[ X[i] ][ Y[i] ].occupied = true;
                }
                m[t + i].grids[ X[i-1] ][ Y[i-1] ].occupied = false;
                for(int q = t + i; q <= time_max; q++){
                    m[q].grids[ X[i-1] ][ Y[i-1] ].occupied = false;
                }
                for(int q =t + i;q <= time_max; q++){
                    m[q].grids[ X[i] ][ Y[i] ].pollutedTimes.insert(m[q].grids[ X[i] ][ Y[i] ].type_drop);
                }
                  Drop mix_drop;
                mix_drop.pos = Point(X[i], Y[i]);
                mix_drop.pos = my_type;
        //                    mix_drop.opearated = true;
                drops[t + i].dropvector.push_back(mix_drop);
            }
        }
        else if(cmd == "Move"){
            sounds[t + 1].push_back(1);
            m[t + 1].grids[ X[1] ][ Y[1] ].occupied = true;
            for(int q = t + 1; q <= time_max; q++){
                m[q].grids[ X[1] ][ Y[1] ].occupied = true;
            }
            m[t + 1].grids[ X[0] ][ Y[0] ].occupied = false;
            for(int q = t + 1; q <= time_max; q++){
                m[q].grids[ X[0] ][ Y[0] ].occupied = false;
            }
//            m[t + 1].grids[ X[1] ][ Y[1] ].pollutedTimes++;
            for(int q = t + 1; q <= time_max; q++)
                m[q].grids[ X[1] ][ Y[1] ].pollutedTimes.insert(m[q].grids[ X[1] ][ Y[1] ].type_drop);   //Add polluted times

            Drop move_drop;
            move_drop.opearated = true;
            move_drop.pos = Point(X[1], Y[1]);
            move_drop.type = typenum;
            m[t + 1].grids[X[1]][Y[1]].type_drop=m[t].grids[X[0]][Y[0]].type_drop;
            //            m[t + 1].grids[X[1]][Y[1]].type_drop=typenum;
            for(int q=t+2;q<=time_max;q++){
                m[q].grids[X[1]][Y[1]].type_drop=m[t].grids[X[0]][Y[0]].type_drop;
            }
            drops[t + 1].dropvector.push_back(move_drop);
        }
        else if(cmd == "Split"){
            sounds[t + 1].push_back(3);
            sounds[t + 2].push_back(4);
            int x1 = X[0]; int y1 = Y[0];
            int x2 = X[1]; int y2 = Y[1];
            int x3 = X[2]; int y3 = Y[2];

            m[t + 2].grids[ x1 ][ y1 ].occupied = false;
            for(int q=t+2;q<=time_max;q++){
                m[q].grids[ x1 ][ y1 ].occupied = false;
            }
            m[t+1].grids[x1][y1].occupied=true;
            m[t+1].grids[x1][y1].streched=true;
            m[t+1].grids[x1][y1].shuZhi=(x1 == x2 ? true : false);

            m[t + 2].grids[ x2 ][ y2 ].occupied = true;
            for(int q = t + 2; q <= time_max; q++){
                m[q].grids[ x2 ][ y2 ].occupied = true;
            }
            m[t + 2].grids[ x3 ][ y3 ].occupied = true;
            for(int q = t + 2; q <= time_max; q++){
                m[q].grids[ x3 ][ y3 ].occupied = true;
            }

            for(int q = t + 2; q <= time_max; q++)
                m[q].grids[ x2 ][ y2 ].pollutedTimes.insert(m[q].grids[ x2 ][ y2 ].type_drop);
            for(int q = t + 2; q <= time_max; q++)
                m[q].grids[ x3 ][ y3 ].pollutedTimes.insert(m[q].grids[ x3 ][ y3 ].type_drop);

//            m[t + 2].grids[ x2 ][ y2 ].pollutedTimes = m[t + 1].grids[ x2 ][ y2 ].pollutedTimes + 1;   //Add polluted times
//            m[t + 2].grids[ x3 ][ y3 ].pollutedTimes = m[t + 1].grids[ x3 ][ y3 ].pollutedTimes + 1;   //Add polluted times

            Drop drop1, drop2;
            Drop dropLonging;
            drop1.pos = Point(x2, y2);
            drop2.pos = Point(x3, y3);
            dropLonging.pos = Point(x1, y1);
            dropLonging.longing = true;
            dropLonging.shuZhi = (x1 == x2 ? true : false);

            typenum ++;
            drop1.type = typenum;
             m[t+2].grids[x2][y2].type_drop=typenum;
             for(int q=t+3;q<=time_max;q++){
                 m[q].grids[x2][y2].type_drop=typenum;
             }
            typenum ++;
            drop2.type = typenum;
             m[t+2].grids[x3][y3].type_drop=typenum;
             for(int q=t+3;q<=time_max;q++){
                 m[q].grids[x3][y3].type_drop=typenum;
             }
            drops[t+1].dropvector.push_back(dropLonging);
            drops[t+2].dropvector.push_back(drop1);
            drops[t+2].dropvector.push_back(drop2);
        }
        else if(cmd == "Merge"){
            sounds[t + 1].push_back(2);
            int x1 = X[0]; int y1 = Y[0];
            int x2 = X[1]; int y2 = Y[1];
            int x3 = (x1 + x2) / 2; int y3 = (y1 + y2) / 2;
            m[t + 2].grids[ x1 ][ y1 ].occupied = false;
            for(int q=t+1;q<=time_max;q++){
                m[q].grids[ x1 ][ y1 ].occupied = false;
            }
            m[t + 2].grids[ x2 ][ y2 ].occupied = false;
            for(int q=t+1;q<=time_max;q++){
                m[q].grids[ x2 ][ y2 ].occupied = false;
            }
            m[t + 2].grids[ x3 ][ y3 ].occupied = true;
            for(int q=t+2;q<=time_max;q++){
                m[q].grids[ x3 ][ y3 ].occupied = true;
            }
            m[t+1].grids[x3][y3].occupied=true;
            m[t+1].grids[x3][y3].streched=true;
            m[t+1].grids[x3][y3].shuZhi=(x1 == x2 ? true : false);

            Drop dropMerging;
            dropMerging.longing = true;
            dropMerging.pos = Point(x3, y3);
            dropMerging.opearated = true;
            dropMerging.shuZhi = (x1 == x3 ? true : false);
//            m[t + 2].grids[ x3 ][ y3 ].pollutedTimes++;
            for(int q = t +2 ; q <= time_max; q++){
                m[q].grids[ x3 ][ y3 ].pollutedTimes.insert(m[q].grids[ x3 ][ y3 ].type_drop);
            }
            typenum ++;
            Drop new_drop;
            new_drop.pos = Point(x3, y3);
            new_drop.type = typenum;
            m[t+2].grids[x3][y3].type_drop=typenum;
            for(int q=t+3;q<=time_max;q++){
                m[q].grids[x3][y3].type_drop=typenum;
            }
            drops[t+2].dropvector.push_back(new_drop);
        }
        else {
            cout << "No match" << endl;
            return;
        }
    }
}


int dist(Point a, Point b)
{
    return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

bool MainWindow::isValid()
{
  //  vector<int> dis;

    for (int t = 0; t <= time_max; t++) {
        for (int i = 1; i <= this->initer.rows; i++) {
            for (int j = 1; j <= this->initer.cols; j++) {
                for (int p = 1; p <= this->initer.rows; p++){
                    for (int q = 1; q <= this->initer.cols; q++){
                        if(m[t].grids[i][j].occupied==true&&m[t].grids[p][q].occupied==true){
                            if(p!=i&&q!=j){
                                if(m[t].grids[i][j].streched==false&&m[t].grids[i][j].streched==false){
                            if(dist(i,j,p,q)<4){
                                return false;
                            }
                                }
                            }
                        }
                    }
                }
                //dis.push_back(dist(drops[t].dropvector[i].pos, drops[t].dropvector[j].pos));
            }
        }
    }
    for (int t = 0; t < time_max; t++) {
        for (int i = 1; i <= this->initer.rows; i++) {
            for (int j = 1; j <= this->initer.cols; j++) {
                for (int p = 1; p <= this->initer.rows; p++){
                    for (int q = 1; q <= this->initer.cols; q++){
                        if(m[t].grids[i][j].occupied==true&&m[t+1].grids[p][q].occupied==true){
                                if(p!=i&&q!=j){
                                    if(m[t].grids[i][j].streched==false&&m[t+1].grids[i][j].streched==false){
                                if(dist(i,j,p,q)<4){
                                    return false;
                                }
                                }
                                }
                            }
                        }
                    }
                }
                //dis.push_back(dist(drops[t].dropvector[i].pos, drops[t].dropvector[j].pos));
            }
        }
    return true;
}
//bool MainWindow::isValid()
//{
//    vector<int> dis;

//    for (int t = 0; t < time_max + 2 + 1; t++) {
//        for (int i = 0; i < int(drops[t].dropvector.size()); i++) {
//            for (int j = 0; j < int(drops[t].dropvector.size()); j++) {
//                dis.push_back(dist(drops[t].dropvector[i].pos, drops[t].dropvector[j].pos));
//            }
//        }
//    }
//    for (int t = 0; t < time_max + 2; t++) {
//        for (int i = 0; i < int(drops[ t+1 ].dropvector.size()); i++) {
//            for (int j = 0; j < int(drops[ t ].dropvector.size()); j++) {
//                dis.push_back(dist(drops[t + 1].dropvector[i].pos, drops[t].dropvector[j].pos));
//            }
//        }
//    }
//    for(int i = 0; i < int(dis.size()); i++){
//        if(dis[i] > 4)
//            return false;
//    }
//    return true;
//}

void MainWindow::on_buttonPlay_clicked()
{
//    cout << "Start" << time_max << endl;
//    for (int i = 0; i < time_max; i++) {
//        connect(timer, SIGNAL(timeout()), this, SLOT());
//        timer->start(1000);
//    }
//    cout << "end" << time_max << endl;
//    time_curr = 0;
//    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
//    for(int i = 0; i < time_max + 2; i++){
//        timer->start(1000);
//        time_curr++;
//        this->update();
//    }
//    for(int i = 0; i < time_max; i++){
//        QElapsedTimer t;
//        t.start();
//        while(t.elapsed()<1000);
//        time_curr++;
//        this->update();
//    }
    if(pause){
        QMessageBox::information(nullptr, "Paused", "Paused, click to continue...");
        return;
    }
    int i = time_curr;
    while(i <= time_max){
//        QElapsedTimer timer;
//        timer.start();
//        while(timer.elapsed() < 1000);

        ui->lcdNumber->display(time_curr);
        //cout << "Sound..." << endl;
        QTime qtime = QTime::currentTime().addMSecs(500);
        while(QTime::currentTime() < qtime){
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
            if(sounds[time_curr].size() == 0){
                s1.play();
                cout << "If" << endl;
            }
            else{
                cout << "else" << endl;
                if(sounds[time_curr][0] == 1)
                    s1.play();
                if(sounds[time_curr][0] == 2)
                    s2.play();
                if(sounds[time_curr][0] == 3)
                    s3.play();
                if(sounds[time_curr][0] == 4)
                    s4.play();
                else {
                    s1.play();
                }
            }
        }
        this->repaint();

        //cout << "SoundEnd..." << endl;
        time_curr++;
        if(time_curr > time_max){
            QMessageBox::information(nullptr, "Time Up", "Time is up...", QMessageBox::Ok, QMessageBox::Ok);
            return;
        }
        i++;
    }
}

void MainWindow::on_buttonCheck_clicked()
{

    MainWindow::manipulation();

    if(!isValid()){
        QMessageBox::information(nullptr, "Invalid", "<font color=red> Invalid </font>\nThe input doesn't satisfy the restriction\nThe program will exit...", QMessageBox::Ok, QMessageBox::Ok);
    }
    else {
        QMessageBox::information(nullptr, "Valid", "The operation is <font color=green> Valid </font>!", QMessageBox::Ok, QMessageBox::Ok);
    }
}

void MainWindow::on_buttonPre_clicked()
{
    time_curr --;
    if(time_curr < 0){
        QMessageBox::information(nullptr, "Invalid", "Time cannot be minus... ", QMessageBox::Ok, QMessageBox::Ok);
        time_curr = 0;
        return;
     }
    ui->lcdNumber->display(time_curr);

//    ui->lcdNumber->setDigitCount(time_curr);
//    ui->lcdNumber->update();
    this->repaint();
    if(sounds[time_curr].size() == 0)
        s1.play();
    else{
        if(sounds[time_curr][0] == 1)
            s1.play();
        if(sounds[time_curr][0] == 2)
            s2.play();
        if(sounds[time_curr][0] == 3)
            s3.play();
        if(sounds[time_curr][0] == 4)
            s4.play();
        else {
            s1.play();
        }
    }
}
void MainWindow::on_bunttonNex_clicked()
{
    time_curr ++;

    //++++++++++++++++++++++++++++++++++++++
    if(time_curr > time_max){
        QMessageBox::information(nullptr, "Time Up", "Time is up...", QMessageBox::Ok, QMessageBox::Ok);
        return;
    }
//        ++++++++++++++++++++++++++++++++++++++
    ui->lcdNumber->display(time_curr);
//    ui->lcdNumber->setDigitCount(time_curr);
//    ui->lcdNumber->update();
    this->repaint();
    if(sounds[time_curr].size() == 0)
        s1.play();
    else{
        if(sounds[time_curr][0] == 1)
            s1.play();
        if(sounds[time_curr][0] == 2)
            s2.play();
        if(sounds[time_curr][0] == 3)
            s3.play();
        if(sounds[time_curr][0] == 4)
            s4.play();
        else {
            s1.play();
        }
    }

//    ui->lcdNumber->update();
}

void MainWindow::on_pushButton_5_clicked() //button_5 is "Original"
{
    time_curr = 0;
    ui->lcdNumber->display(time_curr);
    this->repaint();
}

void MainWindow::on_buttonpol_clicked()
{
    if(time_curr < time_max){
//        if(time_curr < time_max){
        QMessageBox::information(nullptr, "Not finished", "Please wait...", QMessageBox::Ok, QMessageBox::Ok);
        return;
    }
    s5.play();
    time_curr = time_max;
    this->repaint();
}

void MainWindow::on_buttonPau_clicked()
{
    pause = !pause;
    return;
}
