#ifndef HEADERS_H
#define HEADERS_H


#include <QApplication>
#include <QLabel>
#include <QWidget>
#include <QPushButton>
#include <QDialog>
#include <QGroupBox>
#include <QRadioButton>
#include <QtGui>
#include <QSpinBox>
#include <QHBoxLayout>
#include <QSlider>
#include <QLineEdit>
#include <QCheckBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLayout>
#include <QScrollBar>
#include <QMainWindow>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QKeySequence>
#include <QToolBar>
#include <QObject>
#include <QMessageBox>
#include <QFileDialog>
#include <QColorDialog>
#include <QInputDialog>
#include <QMouseEvent>
#include <QCloseEvent>
#include <QTime>
#include <QRasterWindow>
#include <QPaintDevice>
#include <QPaintEngine>
#include <QPainter>
#include <QGraphicsScene>
#include <QFileDialog>
#include <QGraphicsView>
#include <QtMultimedia/QAudio>
#include <vector>
#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <set>


#endif // HEADERS_H
