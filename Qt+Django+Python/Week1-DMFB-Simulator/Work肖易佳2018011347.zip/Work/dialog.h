#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <vector>
#include <string>
#include <QString>
#include <QMainWindow>

using namespace std;

class DataPack
{
public:
    vector<int> input_x, input_y;
    int output_x, output_y;
    int rows, cols;
    QString path_DataPack;
    bool isChosen = false;
    vector<string> cmd;
    vector<string> data;
};


namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();
    DataPack dp;
    QString pathFromDialog;
    bool chosen = false;


signals:
    void send_Init_DataPack(DataPack ini_pack);

private slots:
    void on_buttonBox_accepted();

    void on_add_input_clicked();

    void on_enter_path_clicked();

    void on_checkRow_clicked();

    void on_checkCol_clicked();

private:
    Ui::Dialog *ui;
};



#endif // DIALOG_H
