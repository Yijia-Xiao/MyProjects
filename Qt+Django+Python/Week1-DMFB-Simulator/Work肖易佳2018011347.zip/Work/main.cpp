#include "mainwindow.h"
#include "dialog.h"
#include "headers.h"
#include "grid.h"
#include "waterdrop.h"
using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    a.exec();
    return 0;
}




//以下全部为历史代码
//    cout << w.cmd.size() << endl;
//    Dialog * d = new Dialog;
//    d->show();

//    if(isValid())
//        cout << "Good" << endl;
//    else
//        cout << "No" << endl;




//void manipulation(string cmd, string data)
//{
//    //process
//    data = data.substr(0, data.size() - 1);
//    char *a = new char[data.size() + 1];
//    strcpy(a, data.c_str());
//    char * p;
//    p = strtok(a, ",");
//    vector<int> ints;
//    while(p){
//        ints.push_back(stoi(p));
//        p = strtok(nullptr, ",");
//    }
//    int t = ints[0];

//    if(cmd == "Input"){
//        typenum ++;
//        bool g = false;
//        int X = ints[1]; int Y = ints[2];
//        for(int i = 0; i < inputs.size(); i++)
//            if((inputs[i].x == X && (abs(inputs[i].y - Y) == 1)) | (inputs[i].y == Y && (abs(inputs[i].x - X) == 1))){
//                g = true;
//                break;
//            }
//        if(g){
//            m[t].grids[X][Y].occupied = true;
//            m[t].grids[X][Y].pollutedTimes++;   //Add polluted times

//            //record the TYPE CHANGES
//            m[t].grids[X][Y].curr.type = typenum;
//            //

//            {
//            QDialog *dialog = new QDialog();
//            QMessageBox::information(nullptr, "Input Okay", "The case is okay", QMessageBox::Ok, QMessageBox::Ok);
//            dialog->show();
//            }

//        }
//        else{
//            QDialog *dialog = new QDialog();
//            QMessageBox::critical(nullptr, "Input Error Case", "The case is error, the demo will close", QMessageBox::Ok, QMessageBox::Ok);
//            dialog->show();
//            exit(0);
//        }
//    }

//    else if(cmd == "Output"){
//        int X = ints[1]; int Y = ints[2];
//        if((output.x == X && (abs(output.y - Y) == 1)) | (output.y == Y && (abs(output.x - X) == 1))){
//            m[t].grids[ints[1]][ints[2]].occupied = false;
//            {
//            QDialog *dialog = new QDialog();
//            QMessageBox::information(nullptr, "Output Okay", "The case is okay", QMessageBox::Ok, QMessageBox::Ok);
//            dialog->show();
//            }

//        }
//        else{
//            QDialog *dialog = new QDialog();
//            QMessageBox::critical(nullptr, "Output Error Case", "The case is error, the demo will close", QMessageBox::Ok, QMessageBox::Ok);
//            dialog->show();
//            exit(0);
//        }
//    }
//    else if(cmd == "Mix"){
//        for(int i = 1; i < (ints.size() - 1)/2; i++){
//            m[t + i].grids[ ints[2*i + 1] ][ ints[2*i + 2] ].occupied = true;
//            m[t + i].grids[ ints[2*i - 1] ][ ints[2*i] ].occupied = false;

//            m[t + i].grids[ ints[2*i-1] ][ ints[2*i] ].curr = m[t + 1].grids[ ints[2*i-1] ][ ints[2*i] ].curr;
//            m[t + i].grids[ ints[2*i-1] ][ ints[2*i] ].pollutedTimes++;
//        }
//    }
//    else if(cmd == "Move"){
//        m[t + 1].grids[ ints[3] ][ ints[4] ].occupied = true;
//        m[t + 1].grids[ ints[1] ][ ints[2] ].occupied = false;

//        m[t + 1].grids[ ints[3] ][ ints[4] ].curr = m[t + 1].grids[ ints[1] ][ ints[2] ].curr;
//        m[t + 1].grids[ ints[3] ][ ints[4] ].pollutedTimes++;
//    }
//    else if(cmd == "Split"){
//        int x1 = ints[1]; int y1 = ints[2];
//        int x2 = ints[3]; int y2 = ints[4];
//        int x3 = ints[5]; int y3 = ints[6];
//        m[t + 2].grids[ x1 ][ y1 ].occupied = false;
//        m[t + 2].grids[ x2 ][ y2 ].occupied = true;
//        m[t + 2].grids[ x3 ][ y3 ].occupied = true;

//        m[t + 2].grids[ x2 ][ y2 ].pollutedTimes++;
//        m[t + 2].grids[ x3 ][ y3 ].pollutedTimes++;
//        typenum ++;
//        m[t + 2].grids[ x2 ][ y2 ].curr.type = typenum;
//        typenum ++;
//        m[t + 2].grids[ x3 ][ y3 ].curr.type = typenum;
//    }
//    else if(cmd == "Merge"){
//        int x1 = ints[1]; int y1 = ints[2];
//        int x2 = ints[3]; int y2 = ints[4];
//        int x3 = (x1 + x2) / 2; int y3 = (y1 + y2) / 2;
//        m[t + 2].grids[ x3 ][ y3 ].occupied = true;
//        m[t + 2].grids[ x1 ][ y1 ].occupied = false;
//        m[t + 2].grids[ x2 ][ y2 ].occupied = false;

//        m[t + 2].grids[ x3 ][ y3 ].pollutedTimes++;
//        typenum ++;
//        m[t + 2].grids[ x3 ][ y3 ].curr.type = typenum;
//    }
//    else {
//        cout << "No match" << endl;
//        return;
//    }
//}
//bool isValid(int t)
//{
//#define SIZE 8
//    vector<int> X, X2;
//    vector<int> Y, Y2;
//    bool g1 = true, g2 = true;
//    for(int i = 1; i < SIZE; i++){
//        for (int j = 1; j < SIZE; j++){
//            if(m[t].grids[i][j].occupied)
//            {    X.push_back(i); Y.push_back(j);}

//            if(m[t + 1].grids[i][j].occupied)
//            {    X2.push_back(i); Y2.push_back(j);}
//        }
//    }
//    for(int i = 0; i < X.size(); i++)
//        for (int j = 0; j < Y.size(); j++) {
//            g1 = g1 && (abs(X[i] - X[j])>1 || abs(Y[i] - Y[j])>1);
//        }
//    for(int i = 0; i < X2.size(); i++)
//        for (int j = 0; j < Y2.size(); j++) {
//            g2 = g2 && (abs(X2[i] - X[j])>1 || abs(Y2[i] - Y[j])>1);
//        }
//    return (g1 && g2);
//}
